#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import miniball
import matplotlib.pyplot as plt
import math
import random
import numpy as np



from sklearn.metrics import classification_report, confusion_matrix
import faiss
from sklearn.preprocessing import StandardScaler
import statsmodels.api as sm
import numpy as np


# In[2]:


#get data
data = pd.read_csv("country_names_first_embeddings.csv", header=None)
word_embeddings = data.reset_index()
# word_embeddings = word_embeddings[word_embeddings[1537] != 'Sao Tome and Principe']
word_embeddings = word_embeddings[list(range(0, 768)) + [1537, 1538]]
word_embeddings[1537] = word_embeddings[1537].apply(lambda x: x.lower())
word_embeddings['tokens'] = word_embeddings[1538]


# In[3]:


# word_embeddings = pd.read_csv("../old_files/embeddings/base_filtered_sentences.csv", header=None)
# word_embeddings = word_embeddings[list(range(0, 768)) + [1536, 1537]]
# word_embeddings['tokens'] = word_embeddings[1537]
# word_embeddings[1537] = word_embeddings[1536].apply(lambda x: x.lower())


# In[4]:


tokens = word_embeddings[[1537, 'tokens']]


# In[5]:



# word_embeddings[1538] = word_embeddings[1537].apply(lambda x: country_mapping[x])


# In[6]:


#read in frequency data
wiki_freq = pd.read_csv("../../Semantic_Distortions/WiC/wordfreq.txt", header=None, sep = ' ')

book_corpus_frequency = pd.read_csv("../../Semantic_Distortions/WiC/book_corpus_frequency.csv")

wiki_freq.columns = ['wiki_word', 'wiki_count']
book_corpus_frequency.columns = ['bookcorpus_word', 'bookcorpus_count']

freq = wiki_freq.set_index('wiki_word').join(book_corpus_frequency.set_index("bookcorpus_word"), how='outer')
freq = freq.reset_index()
freq = freq.dropna(subset=['index'])
freq = freq.fillna(0)

freq['freq'] = freq['wiki_count'] + freq['bookcorpus_count']
freq['freq_logged'] = freq['freq'].apply(lambda x: math.log(x,2))
freq['percent_change'] = freq['freq'] / freq['wiki_count']


# In[7]:


#get GDP data
gdp_data = pd.read_csv("gdp_data.csv")
gdp_data = gdp_data[['other country name', 'gdp/per capita', 'year of estimate', 'Country', 'Continent', 'gdp']]
gdp_data['other_name'] = gdp_data['other country name'].apply(lambda x: x.lower())
gdp_data['gdp'] = gdp_data['gdp'].apply(lambda x: float(str(x).replace(',', '')))
gdp_data['gdp_logged'] = gdp_data['gdp'].apply(lambda x: math.log(x))


gdp_data = gdp_data.set_index("other_name").join(freq.set_index("index"), how='outer').dropna(subset=['gdp'])
gdp_data = gdp_data[['Continent', 'gdp/per capita', 'gdp', 'gdp_logged', 'freq', 'freq_logged']]
gdp_data = gdp_data.reset_index()
gdp_data


# In[8]:


gdp_data


# # Miniballs

# In[9]:


WORD_INDEX = 1537
word_embeddings = word_embeddings[list(range(0, 768)) + [1537] + ['tokens']]


# In[10]:


import random
import numpy as np
def create_miniballs(all_word_embeddings, filename):
    
    #drop duplicate word embeddings
    all_word_embeddings = all_word_embeddings.drop_duplicates(keep='first')
    
    #creating convex hulls or miniballs
    all_word_embeddings = all_word_embeddings.groupby(WORD_INDEX)
    result = pd.DataFrame()
    for name, group in all_word_embeddings:
#         n = 768
#         print(group.values)
        current = np.delete(group.values, 768, 1)
        values = []
        for x in range(0, 100):
            sample = current[np.random.choice(current.shape[0], 10, replace=False), :]
            C, r2 = miniball.get_bounding_ball(np.array(sample, dtype='float'))
            values.append(r2)
            
        r2 = np.array(values).mean()
        std = np.array(values).std()
        result = result.append([[name, r2, std, C]])
        print(name, r2, std)
        
    result.columns=['keyword', 'r2', 'std', "centroid"]

#     #adding word frequency
    result = result.set_index('keyword').join(freq.set_index('index'), how='outer')
    result = result.dropna(subset=['r2'])
    result.to_csv(filename)
    return result


# In[11]:


# result = create_miniballs(word_embeddings, "miniballs_first.csv")
# centroids = pd.read_csv("miniballs_first.csv")


# In[12]:


#Calclate distance from centoirds
# sampled = word_embeddings.groupby(1537).apply(lambda x: x.sample(n=10)).reset_index(drop=True)
# distances = pd.DataFrame()
# for n, row in centroids.iterrows():
#     centroid = np.array(row['centroid'].replace('[',"").replace("]", "").split()).astype(float)
#     centroid_name = row['Unnamed: 0']
#     for index, instance in sampled.iterrows():
#         norm = np.linalg.norm(centroid - np.array(instance[0:768]))
#         distances = distances.append([[norm, centroid_name, instance[1537]]])
#     print(centroid_name)
# distances


# In[13]:


tokens = word_embeddings[[1537, 'tokens']]


# In[14]:


import pandas as pd
result = pd.read_csv("miniballs_first.csv")

result['Radius'] = result['r2'].apply(lambda x: math.sqrt(x))
result['keyword'] = result['Unnamed: 0']
result = result[['keyword', 'Radius', 'std']]
result = result.set_index("keyword").join(gdp_data.set_index("index"), how='outer')
# result = result.dropna(subset=['r2'])
result['gdp'] = result['gdp'].apply(lambda x: float(str(x).replace(',', '')))
result['gdp_capita'] = result['gdp/per capita'].apply(lambda x: float(str(x).replace(',', '')))
result = result.reset_index()
result = result.set_index("index").join(tokens.set_index(1537)).reset_index()
result


# In[15]:


# result = pd.read_csv("country_miniballs.csv", header=None)
# result['r2'] = result[0].apply(lambda x: float(x.split(" ")[-2]))
# result['Radius'] = result['r2'].apply(lambda x: math.sqrt(x))
# result['std'] = result[0].apply(lambda x: float(x.split(" ")[-1]))
# result['keyword'] = result[0].apply(lambda x: " ".join(x.lower().split(" ")[:-2]))
# result = result.set_index("keyword").join(gdp_data.set_index("index"), how='outer')
# result = result.dropna(subset=['r2'])
# result['gdp'] = result['gdp'].apply(lambda x: float(str(x).replace(',', '')))
# result['gdp_capita'] = result['gdp/per capita'].apply(lambda x: float(str(x).replace(',', '')))
# result = result.reset_index()
# result = result.set_index("index").join(tokens.set_index(1537)).reset_index()


# In[16]:


token_results = result.groupby("tokens").mean().reset_index()
token_results


# In[17]:


Y= result[['Radius']].values
X = result[['gdp']].values

plt.figure(figsize=(10, 5))
plt.scatter(X,Y,s=5,color="blue")
plt.xlabel("GDP of Country", fontsize=15)
plt.ylabel("Radius of Minimum Bounding Sphere", fontsize=15)
plt.xscale("log")
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.title("GDP of country vs radius of minimum bounding sphere",fontsize=15)
plt.show()
plt.savefig('GDP_of_country_vs_radius_of_minimum_bounding_sphere.png')
result['gdp_logged'] = result['gdp'].apply(lambda x: math.log(x, 2))
print(result[['Radius','gdp_logged']].corr("pearson"))


# In[18]:


Y = result[['Radius']].values
X = result[['freq']].values

plt.figure(figsize=(10, 5))
plt.scatter(X,Y,s=5,color="blue")
plt.xlabel("Training Word Frequency", fontsize=15)
plt.ylabel("Radius of Minimum Bounding Sphere", fontsize=15)
plt.xscale("log")
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.title("Frequency vs radius",fontsize=15)
plt.show()
plt.savefig("Word_Frequency_vs_radius.png")
result['freq_logged'] = result['freq'].apply(lambda x: math.log(x, 2))
result[['Radius','freq_logged']].corr("pearson")


# In[19]:


Y = token_results[['Radius']].values
X = token_results[['tokens']].values

plt.figure(figsize=(10, 5))
plt.scatter(X,Y,s=15,color="blue")
plt.xlabel("# of Sub Pieces", fontsize=15)
plt.ylabel("Radius of Minimum Bounding Sphere", fontsize=15)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.title("# of Sub Pieces vs radius",fontsize=15)
plt.show()
plt.savefig("Sub_Pieces_vs_radius.png")
token_results[['Radius','tokens']].corr("pearson")


# In[20]:


# result = result[result['tokens'] == 1]


# In[21]:


import statsmodels.api as sm
import numpy as np

result = result.dropna()

for features in [['freq_logged'], ['gdp_logged'], ['tokens'], ['freq_logged', 'tokens'], ['freq_logged', 'tokens', 'gdp_logged']]:
# for features in [['freq_logged'], ['gdp_logged'], ['freq_logged', 'gdp_logged']]:

    Y = result[['Radius']].values
    X = result[features].values
    X = sm.add_constant(X)
    model = sm.OLS(Y,X)
    results = model.fit()
    print(results.summary(xname=['Constant'] + features, yname='Radius'))


# In[22]:


#average bounding ball and std
# Y= result[['std']].values
# X=result[['Radius']].values

# plt.figure(figsize=(10, 5))
# plt.scatter(X,Y,s=5,color="blue")
# plt.xlabel("STD of radius", fontsize=15)
# plt.ylabel("Radius of Minimum Bounding Sphere", fontsize=15)
# plt.xscale("log")
# plt.xticks(fontsize=14)
# plt.yticks(fontsize=14)
# plt.title("STD of radius vs radius",fontsize=15)
# plt.show()


# result[['std','Radius']].corr("pearson")


# # Cosine Similarity

# In[26]:


from fastdist import fastdist
import numpy as np

def calculate_cosine_similarity(all_word_embeddings):
    result = pd.DataFrame()
    for n, row_n in all_word_embeddings.iterrows():
        temp = []
        temp.append(row_n[1537])
        current_row = row_n[:768]
        for m, row_m in all_word_embeddings.iterrows():
            if(n == m):
                temp.append(0)
                continue
                #just itself
            other_row = row_m[:768]
            similarity = fastdist.cosine(list(np.array(current_row)), list(np.array(other_row)))
#             similarity = cosine_similarity([np.array(current_row), np.array(other_row)])[0][1]
            temp.append(similarity)
        print(n)
        result = result.append([temp])
#         print(row_n[768])
    result.columns = ['Name'] + list(all_word_embeddings[1537].values)
    return result


# In[148]:


for x in range(0, 10):
    cosine_sample = word_embeddings.groupby(1537).apply(lambda x: x.sample(n=1)).reset_index(drop=True)
    cosine_result = calculate_cosine_similarity(cosine_sample)
    cosine_result.to_csv("cosine_result" + str(x) + ".csv")


# In[179]:


cosine_result = pd.read_csv("cosine_result.csv")
cosine_result = cosine_result[['Name'] + list(cosine_result['Name'].values)]
cosine_result


# In[180]:


tokens = word_embeddings[[1537, 'tokens']].groupby(1537).mean().reset_index()
cosine_result = pd.DataFrame(cosine_result.set_index("Name").join(tokens.set_index(1537), how='outer')).reset_index()
cosine_result


# In[136]:


# temp = pd.DataFrame(cosine_result.mean(axis=0)).reset_index().set_index("index").join(gdp_data.set_index("index"), how='outer')
# cosine_result = cosine_result.groupby(cosine_result.index).mean()


# In[181]:


cosine_result = cosine_result.set_index('Name').join(gdp_data.set_index("index"), how='outer')
cosine_result = cosine_result.dropna()
cosine_result


# In[182]:


cosine_result['gdp_quantile'] = pd.qcut(cosine_result['gdp_logged'], q=10, precision=0)
cosine_result['avg'] = cosine_result[cosine_result.index].mean(axis=1)


# In[183]:


cosine_result[['avg', 'gdp_logged']].corr("pearson")


# In[184]:


cosine_result[['avg', 'freq_logged']].corr("pearson")


# In[186]:


cosine_result.plot.scatter(x='tokens', y='avg')


# In[187]:


for x in [(3.6999999999999997, 8.9), (8.9, 10.1), (10.1, 11.1), (11.1, 12.7), (12.7, 16.4)]:
    temp = cosine_result[cosine_result['gdp_logged'] >x[0]][cosine_result['gdp_logged'] < x[1]]
    temp = temp[list(temp.index)]
    temp['avg'] = temp.mean(axis=1)
    print(x, temp['avg'].mean(), len(temp))


# In[188]:


import statsmodels.api as sm
import numpy as np

result = result.dropna()

for features in [['freq_logged'], ['gdp_logged'], ['tokens'], ['freq_logged', 'tokens'], ['freq_logged', 'tokens', 'gdp_logged']]:
# for features in [['freq_logged'], ['gdp_logged'], ['freq_logged', 'gdp_logged']]:

    Y = cosine_result[['avg']].values
    X = cosine_result[features].values
    X = sm.add_constant(X)
    model = sm.OLS(Y,X)
    results = model.fit()
    print(results.summary(xname=['Constant'] + features, yname='Radius'))
    


# In[ ]:


temp[[0, 'gdp_logged']].corr("pearson")


# In[ ]:


temp[[0, 'freq_logged']].corr("pearson")



# In[ ]:


temp.groupby("Continent").mean()


# In[ ]:





# In[ ]:


cosine_sample = word_embeddings.groupby(1537).apply(lambda x: x.sample(n=10)).reset_index(drop=True)
all_word_embeddings = word_embeddings
result = pd.DataFrame()
for n, row_n in all_word_embeddings.iterrows():
    temp = []
    temp.append(row_n[1537])
    current_row = row_n[:768]
    for m, row_m in all_word_embeddings.iterrows():
        if(n == m):
            temp.append(0)
            continue
            #just itself
        other_row = row_m[:768]
        similarity = fastdist.cosine(list(np.array(current_row)), list(np.array(other_row)))
#             similarity = cosine_similarity([np.array(current_row), np.array(other_row)])[0][1]
        temp.append(similarity)
    result = result.append([temp])
#         print(row_n[768])
result.columns = ['Name'] + list(all_word_embeddings[1537].values)


# # Norm

# In[ ]:


og_context = word_embeddings
og_context['norm'] = np.sqrt(np.square(og_context[range(0, 768)]).sum(axis=1))
og_context = og_context.groupby(1537).mean()
og_context = og_context.reset_index()

og_context = og_context.set_index(1537).join(freq.set_index('index'), how='inner')
# og_context.plot(x='freq', y='norm', kind='scatter', logx=True)
# og_context[['freq_logged', 'norm']].corr('pearson')

og_context.plot(x='tokens', y='norm', kind='scatter')
og_context[['norm', 'tokens']].corr('pearson')


# In[ ]:




og_context = first_embedding
og_context['norm'] = np.sqrt(np.square(og_context[range(0, 768)]).sum(axis=1))
og_context = og_context.groupby(1536).mean()
og_context = og_context.reset_index()
og_context[1536] = og_context[1536].apply(lambda x: x.lower())

og_context = og_context.set_index(1536).join(freq.set_index('index'), how='inner')
# og_context.plot(x='freq', y='norm', kind='scatter', logx=True)
# og_context[['freq_logged', 'norm']].corr('pearson')

og_context.plot(x=1537, y='norm', kind='scatter')
og_context[[1537, 'norm']].corr('pearson')



# In[ ]:


og_context[og_context[1537]==1].plot(x='freq_logged', y='norm', kind='scatter')
og_context[og_context[1537]==1][['freq_logged', 'norm']].corr('pearson')


# # Check variance

# In[ ]:


from scipy.spatial import distance
#checking frequency by variance from centroid

og_context = word_embeddings
centroids = og_context.groupby(1537).mean().reset_index()
centroids = centroids[list(range(0, 768)) + [1537, 'norm']]
distances = []
for n, row in centroids.iterrows():
    temp = og_context[og_context[1537] == row[1537]]
    for m, row2 in temp.iterrows():

        distance_value = distance.euclidean(row2[list(range(0, 768))], row[list(range(0, 768))])
        distances.append(distance_value)
    print(row[1537])
    


# In[ ]:


og_context['distance_from_centroid'] = distances

variance = og_context.groupby(1537).var().reset_index()
variance = variance.set_index(1537).join(freq.set_index('index'), how='inner', rsuffix='_r')
variance.plot(x='freq', y='distance_from_centroid', kind='scatter', logx=True)
variance[['freq_logged', 'distance_from_centroid']].corr('pearson')


# In[ ]:


mean = og_context.groupby(1537).mean().reset_index()
mean = mean.set_index(1537).join(freq.set_index('index'), how='inner', rsuffix='_r')
mean.plot(x='freq', y='distance_from_centroid', kind='scatter', logx=True)
mean[['freq_logged', 'distance_from_centroid']].corr('pearson')


# In[ ]:


max_value = og_context.groupby(1537).max().reset_index()
max_value = max_value.set_index(1537).join(freq.set_index('index'), how='inner', rsuffix='_r')
max_value.plot(x='freq', y='distance_from_centroid', kind='scatter', logx=True)
max_value[['freq_logged', 'distance_from_centroid']].corr('pearson')


# In[ ]:


from scipy.spatial import ConvexHull, convex_hull_plot_2d

og_context = get_data()


# In[ ]:


from sklearn.decomposition import PCA
from scipy.spatial import ConvexHull, convex_hull_plot_2d
pca = PCA(n_components=2)
hulls = []
for n, group in og_context.groupby(1537):
    principalComponents = pca.fit_transform(group[list(range(0, 768))])
    hulls.append(ConvexHull(principalComponents).area)

hull_df = og_context.groupby(1537).mean().reset_index()
hull_df['hull'] = hulls
hull_df = hull_df.set_index(1537).join(freq.set_index('index'), how='inner', rsuffix='_r')
hull_df.plot(x='total_count', y='hull', kind='scatter', logx=True)
hull_df['total_count_log'] = np.log(hull_df['total_count'])
hull_df[['total_count_log', 'hull']].corr('pearson')
print(scipy.stats.pearsonr(hull_df['total_count_log'].values, hull_df['hull'].values))


# # How far are your own points from your centroid?

# In[ ]:


distances = pd.read_csv("distance_to_centroids.csv")
distances = distances[['0', '1', '2']]
distances.columns = ['distance', 'country', 'comparison']
distances['country'] = distances['country'].apply(lambda x: x.lower())
distances['comparison'] = distances['comparison'].apply(lambda x: x.lower())


# In[ ]:


temp = distances.set_index("country").join(gdp_data.set_index("index"), how='outer')
temp = temp.reset_index()
temp = temp.dropna(subset=['gdp'])
temp = temp.fillna(0)


temp = temp[temp['index'] == temp['comparison']]
temp = temp.groupby("index").mean().reset_index()
print(temp[['distance', 'gdp_logged']].corr("pearson"))
print(temp[['distance', 'freq_logged']].corr("pearson"))


# # How far are foreign points from your centroid?

# In[ ]:


temp = distances.set_index("country").join(gdp_data.set_index("index"), how='outer')
temp = temp.reset_index()
temp = temp.dropna(subset=['gdp'])
temp = temp.fillna(0)

temp = temp[temp['index'] != temp['comparison']]
temp = temp.groupby("index").mean().reset_index()
print(temp[['distance', 'gdp_logged']].corr("pearson"))
print(temp[['distance', 'freq_logged']].corr("pearson"))


# # Clustering

# In[ ]:


#map country names to numbers
country_mapping = {}
for n, x in enumerate(word_embeddings[1537].unique()):
    country_mapping[x] = n
country_mapping

# train_sample = word_embeddings.groupby(1538).apply(lambda x: x.sample(n=10))
# test_sample = word_embeddings[~word_embeddings.index.isin(train_sample.index)]


# scaler = StandardScaler()
# scaler.fit(train_sample[list(range(0, 768))])

# X_train = np.ascontiguousarray(scaler.transform(train_sample[list(range(0, 768))]))
# X_test = np.ascontiguousarray(scaler.transform(test_sample[list(range(0, 768))]))

# y_train = np.ascontiguousarray(train_sample[1538].values)
# y_test = np.ascontiguousarray(test_sample[1538].values)


# class FaissKNeighbors:
#     def __init__(self, k=5):
#         self.index = None
#         self.y = None
#         self.k = k

#     def fit(self, X, y):
#         self.index = faiss.IndexFlatL2(X.shape[1])
#         self.index.add(X.astype(np.float32))
#         self.y = y

#     def predict(self, X):
#         distances, indices = self.index.search(X.astype(np.float32), k=self.k)
#         votes = self.y[indices]
#         predictions = np.array([np.argmax(np.bincount(x)) for x in votes])
#         return predictions
    
# knn = FaissKNeighbors()
# knn.fit(X_train, y_train)
# y_pred = knn.predict(X_test)

# report = classification_report(y_test, y_pred, output_dict=True)


# report = pd.DataFrame.from_dict(report).transpose()
# report = report.reset_index()
# report = report.set_index(report['index']).join(gdp_data.set_index(1538), how='outer', lsuffix='_l')
# report = report.dropna()

# print(report[['precision', 'gdp_logged']].corr("pearson"))
# print(report[['recall', 'gdp_logged']].corr("pearson"))
# print(report[['f1-score', 'gdp_logged']].corr("pearson"))
# print(report[['precision', 'freq_logged']].corr("pearson"))
# print(report[['recall', 'freq_logged']].corr("pearson"))
# print(report[['f1-score', 'freq_logged']].corr("pearson"))

